package com.novaai.assistant.control

import android.Manifest
import android.content.Context
import android.provider.ContactsContract
import com.novaai.assistant.ai.LlmClient
import com.novaai.assistant.utils.Perms

object Contacts {
    private fun looksLikeNumber(s: String): Boolean {
        val d = s.replace(Regex("[\\s+\\-()]"), "")
        return d.isNotEmpty() && d.all { it.isDigit() }
    }

    private fun lookup(ctx: Context, name: String): String? {
        val q = name.trim()
        if (q.isEmpty()) return null
        val c = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%$q%"), null
        ) ?: return null
        return c.use { if (it.moveToFirst()) it.getString(0) else null }
    }

    fun canRead(ctx: Context) = Perms.has(ctx, Manifest.permission.READ_CONTACTS)

    /** A spoken digit string works without contacts. Otherwise searches contacts, then retries with an English spelling of the name. */
    suspend fun numberFor(ctx: Context, who: String): String? {
        val w = who.trim()
        if (looksLikeNumber(w)) return w.replace(Regex("[\\s\\-()]"), "")
        if (!canRead(ctx)) return null
        lookup(ctx, w)?.let { return it }
        if (LlmClient.provider() == null) return null
        val eng = runCatching {
            LlmClient.chat(listOf(true to "Write this person's name using English letters only. Output only the name, nothing else: $w"))
        }.getOrNull()?.trim()?.trim('.', '"')
        return if (eng.isNullOrBlank() || eng.length > 40) null else lookup(ctx, eng)
    }

    /** WhatsApp wants the country code. Local numbers starting with 0 get the saved country code (default Bangladesh 880). */
    fun intl(num: String, cc: String): String {
        val d = num.filter { it.isDigit() }
        return when {
            num.trim().startsWith("+") -> d
            d.startsWith("00") -> d.drop(2)
            d.startsWith("0") -> cc + d.drop(1)
            else -> d
        }
    }
}
