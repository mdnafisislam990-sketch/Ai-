package com.novaai.assistant.control

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Lets Nova press, swipe, scroll and type on any screen (TikTok, WhatsApp, Settings...).
 * The user must switch it on once: Settings > Accessibility > Nova AI.
 */
class NovaAccessibilityService : AccessibilityService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var autoJob: Job? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        autoJob?.cancel(); instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        autoJob?.cancel(); scope.cancel(); instance = null
        super.onDestroy()
    }

    // ---- global buttons ----
    fun global(action: Int): Boolean = performGlobalAction(action)

    // ---- gestures ----
    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long = 260): Boolean {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, ms)).build()
        return dispatchGesture(g, null, null)
    }

    /** next = true moves to the next video / scrolls the page down (finger moves up). */
    fun swipeVertical(next: Boolean): Boolean {
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val from = dm.heightPixels * (if (next) 0.78f else 0.28f)
        val to = dm.heightPixels * (if (next) 0.28f else 0.78f)
        return swipe(x, from, x, to, 260)
    }

    fun tap(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build()
        return dispatchGesture(g, null, null)
    }

    fun doubleTapCenter(): Boolean {
        val dm = resources.displayMetrics
        val p = Path().apply { moveTo(dm.widthPixels / 2f, dm.heightPixels * 0.45f) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 50))
            .addStroke(GestureDescription.StrokeDescription(p, 150, 50))
            .build()
        return dispatchGesture(g, null, null)
    }

    // ---- auto scroll ----
    fun startAuto(seconds: Int) {
        autoJob?.cancel()
        autoJob = scope.launch {
            while (isActive) {
                delay(seconds * 1000L)
                swipeVertical(true)
            }
        }
    }

    fun stopAuto(): Boolean {
        val was = autoJob?.isActive == true
        autoJob?.cancel(); autoJob = null
        return was
    }

    // ---- screen content ----
    fun clickText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val hits = root.findAccessibilityNodeInfosByText(text)
        for (n in hits) {
            var cur: AccessibilityNodeInfo? = n
            var depth = 0
            while (cur != null && depth < 6) {
                if (cur.isClickable && cur.isEnabled && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                cur = cur.parent
                depth++
            }
        }
        val first = hits.firstOrNull() ?: return false
        val r = Rect()
        first.getBoundsInScreen(r)
        return if (r.isEmpty) false else tap(r.exactCenterX(), r.exactCenterY())
    }

    fun clickSend(): Boolean =
        listOf("Send", "send", "পাঠান", "পাঠাও", "SEND").any { clickText(it) }

    fun typeText(s: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(root) ?: return false
        val cur = f.text?.toString().orEmpty()
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, cur + s)
        }
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun findEditable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isEditable) return n
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            val hit = findEditable(c)
            if (hit != null) return hit
        }
        return null
    }

    companion object {
        @Volatile var instance: NovaAccessibilityService? = null
        fun isOn(): Boolean = instance != null
    }
}
