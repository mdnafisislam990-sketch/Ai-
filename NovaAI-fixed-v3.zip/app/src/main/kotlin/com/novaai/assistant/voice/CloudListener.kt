package com.novaai.assistant.voice

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import com.novaai.assistant.ai.LlmClient
import com.novaai.assistant.ai.NoKeyException
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Always-on mic that stays open the whole time (no restarts, no beeps, no flicker).
 * It detects when you speak, then sends that clip to your AI key to turn it into text.
 */
class CloudListener(
    private val onText: (String) -> Unit,
    private val onHearing: (Boolean) -> Unit,
    private val onFatal: (String) -> Unit
) {
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    @Volatile private var paused = false
    private var worker: Thread? = null

    fun start() {
        if (running) return
        running = true; paused = false
        worker = Thread { loop() }.also { it.isDaemon = true; it.start() }
    }

    fun stop() { running = false; worker?.interrupt(); worker = null; onHearing(false) }
    fun pause() { paused = true; onHearing(false) }
    fun resume() { if (running) paused = false }

    private fun fatal(msg: String) { running = false; main.post { onFatal(msg) } }

    @SuppressLint("MissingPermission")
    private fun loop() {
        val rate = 16000
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = try {
            AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, rate, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 16000))
        } catch (e: Exception) { null }
        if (rec == null || rec.state != AudioRecord.STATE_INITIALIZED) { fatal("Couldn't open the microphone"); return }
        val buf = ShortArray(1600) // 100 ms
        val seg = ByteArrayOutputStream()
        var noise = 250.0
        var speaking = false
        var voiced = 0
        var quiet = 0
        try {
            rec.startRecording()
            while (running) {
                val n = rec.read(buf, 0, buf.size)
                if (n <= 0) { Thread.sleep(20); continue }
                if (paused) { seg.reset(); speaking = false; voiced = 0; quiet = 0; continue }
                var sum = 0.0
                for (i in 0 until n) sum += buf[i].toDouble() * buf[i]
                val rms = Math.sqrt(sum / n)
                val loud = rms > maxOf(noise * 3.0, 600.0)
                if (!loud && !speaking) noise = noise * 0.9 + rms * 0.1
                if (loud) { voiced++; quiet = 0 } else if (speaking) quiet++
                if (loud || speaking) {
                    val bb = ByteBuffer.allocate(n * 2).order(ByteOrder.LITTLE_ENDIAN)
                    for (i in 0 until n) bb.putShort(buf[i])
                    seg.write(bb.array())
                    if (!speaking && voiced >= 2) { speaking = true; onHearing(true) }
                } else { seg.reset(); voiced = 0 }

                if (speaking && (quiet >= 8 || seg.size() > rate * 2 * 20)) {
                    val pcm = seg.toByteArray()
                    seg.reset(); speaking = false; voiced = 0; quiet = 0
                    onHearing(false)
                    if (pcm.size < rate) continue // shorter than half a second: just noise
                    val text = try {
                        LlmClient.transcribe(wav(pcm, rate))
                    } catch (e: NoKeyException) {
                        fatal("Add an AI key first in Settings"); return
                    } catch (e: Exception) { "" }
                    if (text.isNotBlank()) main.post { if (running) onText(text) }
                }
            }
        } catch (e: Exception) {
            // stopped
        } finally {
            runCatching { rec.stop() }
            rec.release()
        }
    }

    private fun wav(pcm: ByteArray, rate: Int): ByteArray {
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray()); h.putInt(36 + pcm.size); h.put("WAVE".toByteArray())
        h.put("fmt ".toByteArray()); h.putInt(16); h.putShort(1); h.putShort(1)
        h.putInt(rate); h.putInt(rate * 2); h.putShort(2); h.putShort(16)
        h.put("data".toByteArray()); h.putInt(pcm.size)
        return h.array() + pcm
    }
}
